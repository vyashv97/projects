import 'package:flutter/material.dart';
main(){
  runApp(MaterialApp(
    debugShowCheckedModeBanner: false,
    home: MyCal(),

  ));
}
class MyCal extends StatefulWidget {
//   const MyCalc({Key? key}) : super(key: key);

  @override
  State<MyCal> createState() => _MyCalcState();
}

class _MyCalcState extends State<MyCal> {
  TextEditingController controller1 = TextEditingController();
  TextEditingController controller2 = TextEditingController();
  int? result=0,num1=0,num2=0;
  add(){
    setState(() {
      num1= int.parse(controller1.text);
      num2= int.parse(controller2.text);
      result = num1! + num2!;
    });
  }
  sub(){
    setState(() {
      num1= int.parse(controller1.text);
      num2= int.parse(controller2.text);
      result = num1! - num2!;
    });
  }
  mul(){
    setState(() {
      num1= int.parse(controller1.text);
      num2= int.parse(controller2.text);
      result = num1! * num2!;
    });
  }
  div(){
    setState(() {
      num1= int.parse(controller1.text);
      num2= int.parse(controller2.text);
      result = num1! ~/ num2!;
    });
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.red,

        title: Text(
            "Beta Calculator"),
      ),
      body: Padding(
        padding: const EdgeInsets.all(10.0),
        child: Column(
          children: [
            Text(
              " $result",
              style: TextStyle(fontSize: 25,fontWeight: FontWeight.bold),
            ),
            SizedBox(
              height:20,
            ),
            TextField(
              controller: controller1,
              decoration: InputDecoration(
                  labelText: "First Number",
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(40))) ,
            ),
            SizedBox(
              height: 30,
            ),
            TextField(
              controller: controller2,
              decoration: InputDecoration(
                  labelText: "Second Number",
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(40))) ,
            ),
            SizedBox(
              height: 30,
            ),
            Row(
              mainAxisAlignment:MainAxisAlignment.spaceEvenly,
              children: [
                ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      primary: Colors.red, // background
                      onPrimary: Colors.white, // foreground
                    ),onPressed: (){
                  add();
                  controller1.clear();
                  controller2.clear();
                }, child: Text("Add")),
                ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      primary: Colors.red, // background
                      onPrimary: Colors.white, // foreground
                    ),onPressed: (){
                  sub();
                  controller1.clear();
                  controller2.clear();
                }, child: Text("Sub")),
                ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      primary: Colors.red, // background
                      onPrimary: Colors.white, // foreground
                    ),onPressed: (){
                  div();
                  controller1.clear();
                  controller2.clear();
                }, child: Text("Div")),
                ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      primary: Colors.red, // background
                      onPrimary: Colors.white, // foreground
                    ),onPressed: (){
                  mul();
                  controller1.clear();
                  controller2.clear();
                }, child: Text("Mul")),
              ],

            ),

          ],
        ),
      ),);
  }
}