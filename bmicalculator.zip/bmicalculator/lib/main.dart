import 'package:flutter/material.dart';
main(){
  runApp(MaterialApp(
    debugShowCheckedModeBanner: false,
    home: MyCal(),

  ));
}
class MyCal extends StatefulWidget {
//   const MyCalc({Key? key}) : super(key: key);

  @override
  State<MyCal> createState() => _MyCalcState();
}

class _MyCalcState extends State<MyCal> {
  TextEditingController controller1 = TextEditingController();
  TextEditingController controller2 = TextEditingController();
  double? result=0,num1=0,num2=0,num3=0;
  add(){
    setState(() {
      num1= double.parse(controller1.text);
      num2= double.parse(controller2.text);
      num3=num2! *num2!;
      result = num1! / num3!;
    });
  }



  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.green,

        title: Text(
            "BMI Calculator"),
      ),
      body: Padding(
        padding: const EdgeInsets.all(10.0),
        child: Column(
          children: [
            Text(
              " $result",
              style: TextStyle(fontSize: 25,fontWeight: FontWeight.bold),
            ),
            SizedBox(
              height:20,
            ),
            TextField(
              controller: controller1,
              decoration: InputDecoration(
                  labelText: "Weight in kg",
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(40))) ,
            ),
            SizedBox(
              height: 30,
            ),
            TextField(
              controller: controller2,
              decoration: InputDecoration(
                  labelText: "Height in meter",
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(40))) ,
            ),
            SizedBox(
              height: 30,
            ),
            Row(
              mainAxisAlignment:MainAxisAlignment.spaceEvenly,
              children: [
                ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      primary: Colors.green, // background
                      onPrimary: Colors.redAccent, // foreground
                    ),onPressed: (){
                  add();
                  controller1.clear();
                  controller2.clear();
                }, child: Text("BMI")),



              ],

            ),

          ],
        ),
      ),);
  }
}